import 'dart:convert';

import 'package:dio/dio.dart';
class youtubeClient {
  final Dio dio = Dio();

  Future<Map<String, dynamic>> getVideosFromYoutube() async {
    try {
      String youtubeUrl = "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics%2Cplayer&chart=mostPopular&maxResults=200&regionCode=IN&key=%20AIzaSyCsUJX7IAnVtMlghfGjo7rYWRvfbku1yBI"; // Your API URL here
      var res = await dio.get(youtubeUrl);
      Map<String, dynamic> videoMap = jsonDecode(res.data);
      return videoMap;
    } catch (error) {
      print("Error has occurred: $error");
      return {}; // Return an empty map to handle errors
    }
  }
}
