import 'package:flutter/material.dart';
import 'package:youtube/screens/homePage.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}
